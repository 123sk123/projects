﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    class Student
    {
        public string sname;
        public int id, clss, sec;
        public float total, avg;
        public float[] marks;
        public Student(string name, int id, int clss, int sec, float total, float avg, float[] marks)

        {
            this.sname = name;
            this.id = id;
            this.clss = clss;
            this.sec = sec;
            this.total = total;
            this.avg = avg;
            this.marks = marks;
        }
    }

}
  

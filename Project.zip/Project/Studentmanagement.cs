﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    class Studentmanagement
    {
        static int count = 0;
        static void Insert()
        {
            float[] marks;
            float total, avg;
            Console.WriteLine(" enter student name,id,clss,sec");
            string name = Console.ReadLine();
            int id = int.Parse(Console.ReadLine());
            int clss = int.Parse(Console.ReadLine());
            int sec = int.Parse(Console.ReadLine());
            Console.WriteLine("enter the no of subjects");
            int n = int.Parse(Console.ReadLine());
            marks = new float[n];
            total = 0f;
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("enter the subject marks" + i + 1);
                marks[i] = float.Parse(Console.ReadLine());
                total = total + marks[i];
            }
            avg = total / n;

            Student s = new Student(name, id, clss, sec, total, avg, marks);
            count++;
            list.Add(s);

        }
        static void Remove(HashSet<Student> s)
        {
            Console.WriteLine("Enter the Student id to delete the record");
            int id = int.Parse(Console.ReadLine());
            foreach (Student x in s)
            {
                if (id == x.id)
                {
                    s.Remove(x);
                    count--;
                    return;
                }
            }
        }
        static void display(HashSet<Student> s)
        {
            Console.WriteLine(" studname \t      id      \t      clss \t    total \t     avg \t ");
            Console.WriteLine("--------\t     ---------\t       ---------\t  -------\t   -------\t");
            foreach (Student x in s)
                Console.WriteLine(x.sname +"\t"+ x.id+"\t" + x.clss+ "\t" + x.sec + "\t" + x.total+ "\t" + x.avg );
        }

        static HashSet<Student> list;
        static void Main(string[] args)
        {

            list = new HashSet<Student>();
            Console.WriteLine("1.insert the details of student ");
            Console.WriteLine("2.delete the details of student ");
            Console.WriteLine("3.display the details");

            while (true)
            {
                Console.WriteLine("Enter your choice");
                int ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        Insert();
                  break;
                    case 2:
                        Remove(list);
                           break;
                    case 3:
                        display(list);
                              break;
                    default:
                        Console.WriteLine("invalid chioce");
                        break;
                }
            }

        }
    }
}





  